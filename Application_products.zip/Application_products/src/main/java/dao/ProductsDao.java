package dao;

import model.Products;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class ProductsDao {

     Products products = new Products();


    ConcurrentHashMap<String, Products> concurrentHashMap = new ConcurrentHashMap<>();{
        concurrentHashMap.put("A1", new Products("A1","Products description",110000,".jpg"));
        concurrentHashMap.put("A1", new Products("A1","Products description",110000,".jpg"));
        concurrentHashMap.put("A1", new Products("A1","Products description",110000,".jpg"));

    }

//    public List<Products>  findAll(){
//        return  concurrentHashMap.put(products.getId(),products);
//    }

//    public void deleteProduct(Integer id){
//        concurrentHashMap.remove(id);
//
//
//    }

//    public void updateProducts(Products products){
//        concurrentHashMap.put(products.getCode(), products);
//    }

    public List<Products> findAll(){
        return new ArrayList<>(concurrentHashMap.values());
    }

    public Products find(String id){
        return concurrentHashMap.get(id);
    }

//    public int getIdDao() {
//
//        return concurrentHashMap.keySet().stream().max(Integer::compareTo).get() + 1;
//    }
}
